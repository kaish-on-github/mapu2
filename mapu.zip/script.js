// 神社資料：爬蟲？條列？
const places = [
  {
    name: "臺北稻荷神社",
    type: "神社",
    lat: 25.0478,
    lng: 121.5170,
    startYear: 1911,
    endYear: 1945,
    description: "日治時期位於臺北的神社。"
  },
  {
    name: "龍山寺",
    type: "寺廟",
    lat: 25.0371,
    lng: 121.4999,
    startYear: 1738,
    endYear: null,
    description: "臺北著名古寺，清代建立，至今仍存在。"
  },
  {
    name: "臺灣神社",
    type: "神社",
    lat: 25.0780,
    lng: 121.5330,
    startYear: 1901,
    endYear: 1945,
    description: "日治時期重要神社，位於圓山一帶。"
  }
];

const map = L.map("map").setView([25.0173, 121.5397], 15);

L.tileLayer("https://tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(map);

// 地點標記

let markers = []; 

function existsInYear(place, year) {
  const started = place.startYear <= year;
  const notEnded = place.endYear === null || place.endYear >= year;
  return started && notEnded;
}

function updateMap(year) {
  markers.forEach(marker => {
    map.removeLayer(marker);
  });

  markers = [];

  const visiblePlaces = places.filter(place => existsInYear(place, year));

  visiblePlaces.forEach(place => {
    const marker = L.marker([place.lat, place.lng])
      .addTo(map)
      .bindPopup(`
        <strong>${place.name}</strong><br>
        類型：${place.type}<br>
        年代：${place.startYear} - ${place.endYear ?? "現在"}<br>
        ${place.description}
      `);

    markers.push(marker);
  });
}

// 設定年代

const yearSlider = document.getElementById("yearSlider");
const yearText = document.getElementById("yearText");

yearSlider.addEventListener("input", function () {
  const year = Number(yearSlider.value);
  yearText.textContent = year;
  updateMap(year);
});

updateMap(2026);